# Weather Dashboard

A simple React weather dashboard that fetches current weather data for any city using the OpenWeatherMap API.

## Features

- Search weather by city name
- Shows temperature, weather condition, humidity, wind speed, and icon

## Setup

1. Get a free API key from [OpenWeatherMap](https://openweathermap.org/api)
2. In `src/components/WeatherDashboard.js`, replace `YOUR_API_KEY_HERE` with your key.
3. Install dependencies and run:

   ```bash
   npm install
   npm start
   ```

## Demo

![Weather Dashboard Screenshot](screenshot.png)

---

## License

MIT