import React, { useState } from "react";

const API_KEY = "YOUR_API_KEY_HERE"; // Get yours at https://openweathermap.org/api

function WeatherDashboard() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchWeather = async () => {
    setLoading(true);
    setError("");
    setWeather(null);

    try {
      const res = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
      );
      if (!res.ok) {
        throw new Error("City not found");
      }
      const data = await res.json();
      setWeather(data);
    } catch (err) {
      setError(err.message || "Error fetching weather");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="weather-dashboard">
      <div className="input-group">
        <input
          type="text"
          placeholder="Enter city..."
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <button onClick={fetchWeather} disabled={!city || loading}>
          {loading ? "Loading..." : "Get Weather"}
        </button>
      </div>
      {error && <div className="error">{error}</div>}
      {weather && (
        <div className="weather-info">
          <h2>
            {weather.name}, {weather.sys.country}
          </h2>
          <p>
            <b>Temperature:</b> {weather.main.temp}°C
          </p>
          <p>
            <b>Condition:</b> {weather.weather[0].description}
          </p>
          <p>
            <b>Humidity:</b> {weather.main.humidity}%
          </p>
          <p>
            <b>Wind:</b> {weather.wind.speed} m/s
          </p>
          <img
            src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
            alt={weather.weather[0].description}
          />
        </div>
      )}
    </div>
  );
}

export default WeatherDashboard;