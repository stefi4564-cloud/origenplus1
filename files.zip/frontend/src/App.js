import React, { useState } from 'react';
import ProductList from './components/ProductList';
import Cart from './components/Cart';
import CheckoutForm from './components/CheckoutForm';
import products from './data/products';
import './styles/main.css';

function App() {
    const [cartItems, setCartItems] = useState([]);
    const [showCheckout, setShowCheckout] = useState(false);

    const handleAddToCart = (product, presentacion) => {
        setCartItems([...cartItems, { product, presentacion }]);
    };

    const handleRemoveFromCart = (idx) => {
        setCartItems(cartItems.filter((_, i) => i !== idx));
    };

    const handleCheckout = () => {
        setShowCheckout(true);
    };

    const handleFinish = () => {
        setCartItems([]);
        setShowCheckout(false);
    };

    return (
        <div style={{maxWidth: '900px', margin: 'auto', fontFamily: 'Montserrat, Arial, sans-serif'}}>
            <h1 className="logo">Origen +</h1>
            <h3 className="text-secondary">Bebidas Saludables - Inmunidad, Energía y Detox</h3>
            {!showCheckout ? (
                <>
                    <ProductList products={products} onAddToCart={handleAddToCart} />
                    <Cart cartItems={cartItems} onRemoveFromCart={handleRemoveFromCart} onCheckout={handleCheckout} />
                </>
            ) : (
                <CheckoutForm onFinish={handleFinish} />
            )}
        </div>
    );
}

export default App;